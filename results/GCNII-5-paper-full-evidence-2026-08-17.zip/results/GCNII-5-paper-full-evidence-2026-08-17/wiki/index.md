# Research Wiki

- 论文数量: 5

## 论文目录

- [05-DropEdge](papers/P-0855A55C3D12/summary.md) (`P-0855A55C3D12`, [PDF](papers/P-0855A55C3D12/source.pdf))
- [04-GAT](papers/P-A7D811A44E1C/summary.md) (`P-A7D811A44E1C`, [PDF](papers/P-A7D811A44E1C/source.pdf))
- [02-DeepGCNs](papers/P-C82A044DF1BD/summary.md) (`P-C82A044DF1BD`, [PDF](papers/P-C82A044DF1BD/source.pdf))
- [03-PairNorm](papers/P-E5BBDC19FCC0/summary.md) (`P-E5BBDC19FCC0`, [PDF](papers/P-E5BBDC19FCC0/source.pdf))
- [01-GCNII](papers/P-FDA616230E48/summary.md) (`P-FDA616230E48`, [PDF](papers/P-FDA616230E48/source.pdf))
