# Wiki Query Pack

- Query: 基于这五篇完整论文，提出一个有证据、可实验验证、避免重复工作的 GNN 新研究方向
- Selected papers: 5

## Evidence Coverage

- 完整可读论文数: 5
- Idea 定稿最低要求: 5
- 仅元数据参考文献数: 103
- 参考文献记录总数: 103
- 是否达到顶刊候选门槛: 是
- 可作为证据的 Paper ID: `P-0855A55C3D12`, `P-A7D811A44E1C`, `P-C82A044DF1BD`, `P-E5BBDC19FCC0`, `P-FDA616230E48`
- 仅元数据或下载失败的参考文献不能作为已读证据。

## Cross-Paper Evidence Matrix

| 论文 | 已解决问题 | 方法机制 | 已知局限 | 作者 Future Work | 可支持方向 | Evidence ID |
|---|---|---|---|---|---|---|
| `P-0855A55C3D12` 05-DropEdge | - 待根据论文证据补充。 | - 待根据论文证据补充。 | - 未确认。 | - 未确认。 | - 仅使用上方可定位证据，证据不足处保持不确定。 | PE-1D5C687408, PE-881757B87C, PE-9405D2A162, PE-D2390D1E22, PE-E97CAD797D |
| `P-A7D811A44E1C` 04-GAT | - 待根据论文证据补充。 | - 待根据论文证据补充。 | - 未确认。 | - 未确认。 | - 仅使用上方可定位证据，证据不足处保持不确定。 | PE-491F3AB11C, PE-976F54AC25, PE-DE2ABEF1EE, PE-F9BB16CB19 |
| `P-C82A044DF1BD` 02-DeepGCNs | - 待根据论文证据补充。 | - 待根据论文证据补充。 | - 未确认。 | - 未确认。 | - 仅使用上方可定位证据，证据不足处保持不确定。 | PE-53D0389F49, PE-7ABF7565E8, PE-DF3F83AD8D, PE-E6DA272E52 |
| `P-E5BBDC19FCC0` 03-PairNorm | - 待根据论文证据补充。 | - 待根据论文证据补充。 | - 未确认。 | - 未确认。 | - 仅使用上方可定位证据，证据不足处保持不确定。 | PE-1DC202CA43, PE-4D863AEFC9, PE-9A7D4298E4, PE-D8465AA5C9 |
| `P-FDA616230E48` 01-GCNII | - 待根据论文证据补充。 | - 待根据论文证据补充。 | - 未确认。 | - 未确认。 | - 仅使用上方可定位证据，证据不足处保持不确定。 | PE-72611C7183, PE-7ECA9C7314, PE-A392E3B074 |

## P-E5BBDC19FCC0: 03-PairNorm

- Relevance score: 22
- Summary: `wiki/papers/P-E5BBDC19FCC0/summary.md`
- PDF: `wiki/papers/P-E5BBDC19FCC0/source.pdf`

## 作者提出的未来工作

- 未确认。

## 作者讨论与局限

- 未确认。

## 对 Idea 生成的提示

- 仅使用上方可定位证据，证据不足处保持不确定。

## 可复用证据

- `PE-4D863AEFC9` | 第 7 页 | Published as a conference paper at ICLR 2020 ual connected” SGC), as we surprisingly ﬁnd it can slow down o versmoothing and beneﬁt SSNC- MV problem. Similar to us, residual connection is a general t echnique that can be applied to any model without changing its architecture. We focus on the com parison between the base models and PAIR NORM -enhanced models, rather than achieving the state of the art performance for SSNC and SSNC-MV. There exist a few other work addressing oversmooth ing (Klicpe
- `PE-D8465AA5C9` | 第 1 页 | arXiv:1909.12223v2  [cs.LG]  13 Feb 2020 Published as a conference paper at ICLR 2020 PAIR NORM : T ACKLING OVERSMOOTHING IN GNN S Lingxiao Zhao Carnegie Mellon University Pittsburgh, P A 15213, USA {lingxia1}@andrew.cmu.edu Leman Akoglu Carnegie Mellon University Pittsburgh, P A 15213, USA {lakoglu}@andrew.cmu.edu ABSTRACT The performance of graph neural nets (GNNs) is known to gradu ally decrease with increasing number of layers. This decay is partly attri buted to oversmooth- ing, where repea
- `PE-1DC202CA43` | 第 8 页 | Published as a conference paper at ICLR 2020 GA T-PN achieve performance that is comparable or better tha n just using skips; (4) performance can be further improved (albeit slightly) by using skips alo ng with PAIR NORM -SI.4 Table 2: Comparison of ‘vanilla’ and (P AIR NORM -SI/ residual)-enhanced GCN performance on Cora, Citeseer, Pubmed, and CoauthorCS for SSNC-MV problem, with 0% and 100% feature missing rate. t represents the skip-step of residual connection. (See A.5 F ig. 8 for more setti
- `PE-9A7D4298E4` | 第 6 页 | Published as a conference paper at ICLR 2020 of SGC on Cora with increasing number of layers, where we employ P AIR NORM after each graph convolution layer, as compared to ‘vanilla’ versions. Simi larly, Figure 3 is for GCN and GA T (PAIR NORM is applied after the activation of each graph convolution). Note that the performance decay with P AIR NORM -at-work is much slower. (See Fig.s 5–6 in Appx. A.3 for other datasets.) While PAIR NORM enables deeper models that are more robust to oversmoothin

## 研究问题

- 待根据论文证据补充。

## 核心方法

- 待根据论文证据补充。

## 主要结果

- 待根据论文证据补充。

## 数据集与实验设置

- 待根据论文证据补充。

## 基于证据推断的 Gap

- 未确认。

## 与其他论文的关系

- 暂无已验证关系。

## 证据边界与未确认内容

- 未确认。

## 作者明确指出的 Gap

- 未确认。

## 基本信息
- Paper ID: `P-E5BBDC19FCC0`
- 原始文件: `paper/uploads/03-PairNorm.pdf`
- Wiki PDF: `wiki/papers/P-E5BBDC19FCC0/source.pdf`

## P-0855A55C3D12: 05-DropEdge

- Relevance score: 20
- Summary: `wiki/papers/P-0855A55C3D12/summary.md`
- PDF: `wiki/papers/P-0855A55C3D12/source.pdf`

## 作者提出的未来工作

- 未确认。

## 作者讨论与局限

- 未确认。

## 对 Idea 生成的提示

- 仅使用上方可定位证据，证据不足处保持不确定。

## 研究问题

- 待根据论文证据补充。

## 可复用证据

- `PE-D2390D1E22` | 第 5 页 | Published as a conference paper at ICLR 2020 Deﬁnition 1 (subspace). LetM :={EC|C∈ RM×C} be anM-dimensional subspace in RN×C, where E∈ RN×M is orthogonal, i.e. ETE = IM , andM≤N. Deﬁnition 2 (ϵ-smoothing). We call theϵ-smoothing of node features happens for a GCN, if all its hidden vectors H (l) beyond a certain layerL have a distance no larger thanϵ (ϵ> 0) with respect to a subspaceM that is independent to the input features, namely, dM(H (l))<ϵ,∀l≥L, (3) wheredM(·) computes the distance betwee
- `PE-1D5C687408` | 第 4 页 | Published as a conference paper at ICLR 2020 4 O UR METHOD : D ROPEDGE This section ﬁrst introduces the methodology of the DropEdge technique as well as its layer-wise variant where the adjacency matrix for each GCN layer is perturbed individually. We also explain how the proposed DropEdge can prevent over-ﬁtting and over-smoothing in generic GCNs. Particularly for over-smoothing, we provide its mathematical deﬁnition and theoretical derivations on showing the beneﬁts of DropEdge. 4.1 M ETHODOLO
- `PE-9405D2A162` | 第 3 页 | Published as a conference paper at ICLR 2020 Gao et al., 2018). These methods directly perform convolution in the graph domain by aggregating the information from neighbor nodes. Recently, several sampling-based methods have been proposed for fast graph representation learning, including the node-wise sampling methods (Hamilton et al., 2017), the layer-wise approach (Chen et al., 2018) and its layer-dependent variant (Huang et al., 2018). Speciﬁcally, GAT (Velickovic et al., 2018) has discussed 
- `PE-881757B87C` | 第 15 页 | Published as a conference paper at ICLR 2020 B.3 T HE VALIDATION LOSS ON DIFFERENT BACKBONES W AND W /O DROPEDGE . Figure 6 depicts the additional results of validation loss on different backbones w and w/o DropEdge. 0 25 50 75 100 125 150 175 200 Epoch 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2Validation Loss Cora ResGCN-6 GCN-6 InceptGCN-6 JKNet-6 ResGCN-6+DropEdge GCN-6+DropEdge InceptGCN-6+DropEdge JKNet-6+DropEdge 0 25 50 75 100 125 150 175 200 Epoch 0.8 1.0 1.2 1.4 1.6 1.8 2.0Validation Loss Cite
- `PE-E97CAD797D` | 第 2 页 | Published as a conference paper at ICLR 2020 0 50 100 150 200 250 300 350 400 Epochs 0.25 0.75 1.25 1.75 Training Loss GCN-8 GCN-8+DropEdge GCN-4 GCN-4+DropEdge 0 50 100 150 200 250 300 350 400 Epochs 0.25 0.75 1.25 1.75 Validation Loss GCN-8 GCN-8+DropEdge GCN-4 GCN-4+DropEdge Figure 1: Performance of Multi-layer GCNs on Cora. We implement 4-layer GCN w and w/o DropEdge (in orange), 8-layer GCN w and w/o DropEdge (in blue) 2. GCN-4 gets stuck in the over-ﬁtting issue attaining low training erro

## 核心方法

- 待根据论文证据补充。

## 主要结果

- 待根据论文证据补充。

## 数据集与实验设置

- 待根据论文证据补充。

## 基于证据推断的 Gap

- 未确认。

## 与其他论文的关系

- 暂无已验证关系。

## 证据边界与未确认内容

- 未确认。

## 作者明确指出的 Gap

- 未确认。

## 基本信息
- Paper ID: `P-0855A55C3D12`
- 原始文件: `paper/uploads/05-DropEdge.pdf`
- Wiki PDF: `wiki/papers/P-0855A55C3D12/source.pdf`

## P-A7D811A44E1C: 04-GAT

- Relevance score: 20
- Summary: `wiki/papers/P-A7D811A44E1C/summary.md`
- PDF: `wiki/papers/P-A7D811A44E1C/source.pdf`

## 作者提出的未来工作

- 未确认。

## 作者讨论与局限

- 未确认。

## 对 Idea 生成的提示

- 仅使用上方可定位证据，证据不足处保持不确定。

## 研究问题

- 待根据论文证据补充。

## 可复用证据

- `PE-491F3AB11C` | 第 3 页 | Published as a conference paper at ICLR 2018 sharing a neural network computation across edges is reminiscent of the formulation of relational networks (Santoro et al., 2017) and V AIN (Hoshen, 2017), wherein relations between objects or agents are aggregated pair-wise, by employing a shared mechanism. Similarly, our proposed at- tention model can be connected to the works by Duan et al. (2017) and Denil et al. (2017), which use a neighborhood attention operation to compute attention coefﬁcients
- `PE-976F54AC25` | 第 9 页 | Published as a conference paper at ICLR 2018 The effectiveness of the learned feature representations may also be investigated qualitatively—and for this purpose we provide a visualization of the t-SNE (Maaten & Hinton, 2008)-transformed feature representations extracted by the ﬁrst layer of a GAT model pre-trained on the Cora dataset (Figure 2). The representation exhibits discernible clustering in the projected 2D space. Note that these clusters correspond to the seven labels of the dataset, v
- `PE-F9BB16CB19` | 第 5 页 | Published as a conference paper at ICLR 2018 all nodes. No eigendecompositions or similar costly matrix operations are required. The time complexity of a single GAT attention head computing F′ features may be expressed asO(|V|FF′ +|E|F′), whereF is the number of input features, and|V| and|E| are the numbers of nodes and edges in the graph, respectively. This complexity is on par with the baseline methods such as Graph Convolutional Networks (GCNs) (Kipf & Welling, 2017). Applying multi-head atte
- `PE-DE2ABEF1EE` | 第 8 页 | Published as a conference paper at ICLR 2018 Table 2: Summary of results in terms of classiﬁcation accuracies, for Cora, Citeseer and Pubmed. GCN-64∗ corresponds to the best GCN result computing 64 hidden features (using ReLU or ELU). Transductive Method Cora Citeseer Pubmed MLP 55.1% 46.5% 71.4% ManiReg (Belkin et al., 2006) 59.5% 60.1% 70.7% SemiEmb (Weston et al., 2012) 59.0% 59.6% 71.7% LP (Zhu et al., 2003) 68.0% 45.3% 63.0% DeepWalk (Perozzi et al., 2014) 67.2% 43.2% 65.3% ICA (Lu & Getoor

## 核心方法

- 待根据论文证据补充。

## 主要结果

- 待根据论文证据补充。

## 数据集与实验设置

- 待根据论文证据补充。

## 基于证据推断的 Gap

- 未确认。

## 与其他论文的关系

- 暂无已验证关系。

## 证据边界与未确认内容

- 未确认。

## 作者明确指出的 Gap

- 未确认。

## 基本信息
- Paper ID: `P-A7D811A44E1C`
- 原始文件: `paper/uploads/04-GAT.pdf`
- Wiki PDF: `wiki/papers/P-A7D811A44E1C/source.pdf`

## P-C82A044DF1BD: 02-DeepGCNs

- Relevance score: 20
- Summary: `wiki/papers/P-C82A044DF1BD/summary.md`
- PDF: `wiki/papers/P-C82A044DF1BD/source.pdf`

## 作者提出的未来工作

- 未确认。

## 作者讨论与局限

- 未确认。

## 对 Idea 生成的提示

- 仅使用上方可定位证据，证据不足处保持不确定。

## 研究问题

- 待根据论文证据补充。

## 可复用证据

- `PE-53D0389F49` | 第 1 页 | DeepGCNs: Can GCNs Go as Deep as CNNs? https://sites.google.com/view/deep-gcns Guohao Li∗ Matthias M¨uller∗ Ali Thabet Bernard Ghanem Visual Computing Center, KAUST, Thuwal, Saudi Arabia {guohao.li, matthias.mueller.2, ali.thabet, bernard.ghanem }@kaust.edu.sa Abstract Convolutional Neural Networks (CNNs) achieve impres- sive performance in a wide variety of ﬁelds. Their success beneﬁted from a massive boost when very deep CNN models were able to be reliably trained. Despite their merits, CNNs f
- `PE-7ABF7565E8` | 第 2 页 | In this work, we present an extensive study of method- ologies that allow for training very deep GCNs. We adapt concepts that were successful in training deep CNNs, mainly residual connections, dense connections, and dilated convolutions. We show how we can incorporate these layers into a graph framework, and present an extensive analysis of the effect of these additions to the accuracy and stabil- ity of deep GCNs. To showcase these layer adaptations, we apply them to the popular task of point 
- `PE-DF3F83AD8D` | 第 7 页 | Ablation Model mIoU ∆mIoU dynamic connection dilation stochastic # NNs # ﬁlters # layers Reference ResGCN-28 52.49 0.00 ✓ ⊕ ✓ ✓ 16 64 28 Dilation 51.98 -0.51 ✓ ⊕ ✓ 16 64 28 49.64 -2.85 ✓ ⊕ 16 64 28 PlainGCN-28 40.31 -12.18 ✓ 16 64 28 Fixed k-NN 48.38 -4.11 ⊕ 16 64 28 43.43 -9.06 16 64 28 Connections DenseGCN-28 51.27 -1.22 ✓ ⊿ ◁ ✓ ✓ 8 32 28 40.47 -12.02 ✓ ✓ ✓ 16 64 28 38.79 -13.70 ✓ ✓ ✓ 8 64 56 49.23 -3.26 ✓ ✓ ✓ 16 64 14 47.92 -4.57 ✓ ✓ ✓ 16 64 7 Neighbors 49.98 -2.51 ✓ ⊕ ✓ ✓ 8 64 28 49.22 -3.27
- `PE-E6DA272E52` | 第 12 页 | Model mIoU ∆mIoU dynamic connection dilation stochastic # NNs # ﬁlters # layers ResEdgeConv-28 52.49 0.00 ✓ ⊕ ✓ ✓ 16 64 28 PlainGCN-28 40.31 -12.18 ✓ 16 64 28 ResGraphSAGE-28 49.20 -3.29 ✓ ⊕ ✓ ✓ 16 64 28 ResGraphSAGE-N-28 49.02 -3.47 ✓ ⊕ ✓ ✓ 16 64 28 ResGIN-ϵ-28 42.81 -9.68 ✓ ⊕ ✓ ✓ 16 64 28 ResMRGCN-28 51.17 -1.32 ✓ ⊕ ✓ ✓ 16 64 28 Table 3. Comparisons of Deep GCNs variants on area 5 of S3DIS . We compare our different types of ResGCN ( ResEdgeConv, Res- GraphSAGE, ResGIN and ResMRGCN) with 28 la

## 核心方法

- 待根据论文证据补充。

## 主要结果

- 待根据论文证据补充。

## 数据集与实验设置

- 待根据论文证据补充。

## 基于证据推断的 Gap

- 未确认。

## 与其他论文的关系

- 暂无已验证关系。

## 证据边界与未确认内容

- 未确认。

## 作者明确指出的 Gap

- 未确认。

## 基本信息
- Paper ID: `P-C82A044DF1BD`
- 原始文件: `paper/uploads/02-DeepGCNs.pdf`
- Wiki PDF: `wiki/papers/P-C82A044DF1BD/source.pdf`

## P-FDA616230E48: 01-GCNII

- Relevance score: 20
- Summary: `wiki/papers/P-FDA616230E48/summary.md`
- PDF: `wiki/papers/P-FDA616230E48/source.pdf`

## 作者提出的未来工作

- 未确认。

## 作者讨论与局限

- 未确认。

## 对 Idea 生成的提示

- 仅使用上方可定位证据，证据不足处保持不确定。

## 研究问题

- 待根据论文证据补充。

## 可复用证据

- `PE-A392E3B074` | 第 2 页 | Simple and Deep Graph Convolutional Networks powerful expression ability of deep nonlinear architectures, which means they are still shallow models. In conclusion, it remains an open problem to design a GCN model that effectively prevents over-smoothing and achieves state-of-the-art results with truly deep network structures. Due to this challenge, it is even unclear whether the network depth is a resource or a burden in designing new graph neu- ral networks. In this paper, we give a positive an
- `PE-7ECA9C7314` | 第 8 页 | Simple and Deep Graph Convolutional Networks Table 5. Mean classiﬁcation accuracy of full-supervised node classiﬁcation. Method Cora Cite. Pumb. Cham. Corn. Texa. Wisc. GCN 85.77 73.68 88.13 28.18 52.70 52.16 45.88 GAT 86.37 74.32 87.62 42.93 54.32 58.38 49.41 Geom-GCN-I 85.19 77.99 90.05 60.31 56.76 57.58 58.24 Geom-GCN-P 84.93 75.14 88.09 60.90 60.81 67.57 64.12 Geom-GCN-S 85.27 74.71 84.75 59.96 55.68 59.73 56.67 APPNP 87.87 76.53 89.40 54.3 73.51 65.41 69.02 JKNet 85.25 (16) 75.85 (8) 88.94 
- `PE-72611C7183` | 第 4 页 | Simple and Deep Graph Convolutional Networks Wℓ to avoid over-ﬁtting, while the later is desirable in semi-supervised tasks where training data is limited. • (Oono & Suzuki, 2020) theoretically proves that the node features of a K-layer GCNs will converge to a subspace and incur information loss. In particular, the rate of convergence depends on sK, where s is the maximum singular value of the weight matrices W(ℓ),ℓ = 0,...,K −1. By replacing W(ℓ) with (1− βℓ)In +βℓW(ℓ) and imposing regularizati

## 核心方法

- 待根据论文证据补充。

## 主要结果

- 待根据论文证据补充。

## 数据集与实验设置

- 待根据论文证据补充。

## 基于证据推断的 Gap

- 未确认。

## 与其他论文的关系

- 暂无已验证关系。

## 证据边界与未确认内容

- 未确认。

## 作者明确指出的 Gap

- 未确认。

## 基本信息
- Paper ID: `P-FDA616230E48`
- 原始文件: `paper/uploads/01-GCNII.pdf`
- Wiki PDF: `wiki/papers/P-FDA616230E48/source.pdf`

## Metadata-only Reference Inventory

以下为输入论文的直接参考文献目录。只有绑定 Paper ID 的条目已进入 Wiki 证据库。

- `R001` | `skipped_limit` | Node classification in social networks -> 仅元数据
- `R002` | `skipped_limit` | Spectral networks and locally connected networks on graphs -> 仅元数据
- `R003` | `skipped_limit` | Fastgcn: Fast learning with graph convolutional networks via importance sampling -> 仅元数据
- `R004` | `skipped_limit` | Convolutional neural networks on graphs with fast localized spectral filtering -> 仅元数据
- `R005` | `skipped_limit` | Journal of the ACM (JACM), 44(5):669–696 -> 仅元数据
- `R006` | `skipped_limit` | Protein interface prediction using graph convolutional networks -> 仅元数据
- `R007` | `skipped_limit` | Large-scale learnable graph convolutional networks -> 仅元数据
- `R008` | `skipped_limit` | Inductive representation learning on large graphs -> 仅元数据
- `R009` | `skipped_limit` | Deep residual learning for image recognition -> 仅元数据
- `R010` | `skipped_limit` | Deep convolutional networks on graph-structured data -> 仅元数据
- `R011` | `skipped_limit` | Improving neural networks by preventing co-adaptation of feature detectors -> 仅元数据
- `R012` | `skipped_limit` | Densely connected convolutional networks -> 仅元数据
- `R013` | `skipped_limit` | Adaptive sampling towards fast graph representation learning -> 仅元数据
- `R014` | `skipped_limit` | Predict then propagate: Graph neural networks meet personalized pagerank -> 仅元数据
- `R015` | `skipped_limit` | IEEE Transactions on Signal Processing, 67(1):97–109 -> 仅元数据
- `R016` | `skipped_limit` | Deepgcns: Can gcns go as deep as cnns? In International Conference on Computer Vision -> 仅元数据
- `R017` | `skipped_limit` | Deeper insights into graph convolutional networks for semi-supervised learning -> 仅元数据
- `R018` | `skipped_limit` | Adaptive graph convolutional neural networks -> 仅元数据
- `R019` | `skipped_limit` | Geometric deep learning on graphs and manifolds using mixture model cnns -> 仅元数据
- `R020` | `skipped_limit` | Learning convolutional neural networks for graphs -> 仅元数据
- `R021` | `skipped_limit` | Automatic differentiation in PyTorch -> 仅元数据
- `R022` | `skipped_limit` | Deepwalk: Online learning of social representations -> 仅元数据
- `R023` | `skipped_limit` | Collective classification in network data. AI magazine, 29(3):93 -> 仅元数据
- `R024` | `skipped_limit` | Rethinking the inception architecture for computer vision -> 仅元数据
- `R025` | `skipped_limit` | Graph attention networks -> 仅元数据
- `R026` | `skipped_limit` | Deep graph library: Towards efficient and scalable deep learning on graphs -> 仅元数据
- `R027` | `skipped_limit` | Zonghan Wu, Shirui Pan, Fengwen Chen, Guodong Long, Chengqi Zhang, and Philip S Yu. A comprehensive survey on graph neural networks -> 仅元数据
- `R028` | `skipped_limit` | Representation learning on graphs with jumping knowledge networks -> 仅元数据
- `R029` | `skipped_limit` | Representation learning on graphs with jumping knowledge networks -> 仅元数据
- `R030` | `skipped_limit` | An end-to-end deep learning architecture for graph classification -> 仅元数据
- `R001` | `skipped_limit` | Diffusion-convolutional neural networks -> 仅元数据
- `R002` | `skipped_limit` | International Conference on Learning Representations (ICLR) -> 仅元数据
- `R003` | `skipped_limit` | Journal of machine learning research, 7 (Nov):2399–2434 -> 仅元数据
- `R005` | `skipped_limit` | Long short-term memory-networks for machine reading -> 仅元数据
- `R006` | `skipped_limit` | Learning phrase representations using rnn encoder-decoder for statistical machine translation -> 仅元数据
- `R007` | `skipped_limit` | Fast and accurate deep network learning by exponential linear units (elus).International Conference on Learning Representations (ICLR) -> 仅元数据
- `R008` | `skipped_limit` | Convolutional neural networks on graphs with fast localized spectral filtering -> 仅元数据
- `R009` | `skipped_limit` | Programmable agents -> 仅元数据
- `R010` | `skipped_limit` | One-shot imitation learning -> 仅元数据
- `R011` | `skipped_limit` | Convolutional networks on graphs for learning molecular fingerprints -> 仅元数据
- `R012` | `skipped_limit` | IEEE transactions on Neural Networks, 9(5):768–786 -> 仅元数据
- `R013` | `skipped_limit` | Understanding the difficulty of training deep feedforward neural networks -> 仅元数据
- `R014` | `skipped_limit` | Marco Gori, Gabriele Monfardini, and Franco Scarselli. A new model for learning in graph domains -> 仅元数据
- `R015` | `skipped_limit` | Neural Information Processing Systems (NIPS) -> 仅元数据
- `R016` | `skipped_limit` | Deep residual learning for image recognition -> 仅元数据
- `R017` | `skipped_limit` | Deep convolutional networks on graph-structured data -> 仅元数据
- `R019` | `skipped_limit` | Zhouhan Lin, Minwei Feng, Cicero Nogueira dos Santos, Mo Yu, Bing Xiang, Bowen Zhou, and Yoshua Bengio. A structured self-attentive sentence embedding -> 仅元数据
- `R020` | `skipped_limit` | Geometric deep learning on graphs and manifolds using mixture model cnns -> 仅元数据
- `R021` | `skipped_limit` | Learning convolutional neural networks for graphs -> 仅元数据
- `R022` | `skipped_limit` | Deepwalk: Online learning of social representations -> 仅元数据
- `R023` | `skipped_limit` | Adam Santoro, David Raposo, David GT Barrett, Mateusz Malinowski, Razvan Pascanu, Peter Battaglia, and Timothy Lillicrap. A simple neural network module for relational reasoning.ar -> 仅元数据
- `R024` | `skipped_limit` | IEEE Transactions on Neural Networks, 20(1):61–80 -> 仅元数据
- `R025` | `skipped_limit` | Netw., 8(3):714–735, May 1997 -> 仅元数据
- `R026` | `skipped_limit` | Journal of machine learning research, 15(1):1929–1958 -> 仅元数据
- `R027` | `skipped_limit` | Proceedings of the National Academy of Sciences, 102(43):15545–15550 -> 仅元数据
- `R028` | `skipped_limit` | Attention is all you need -> 仅元数据
- `R029` | `skipped_limit` | Deep learning via semisupervised embedding -> 仅元数据
- `R030` | `skipped_limit` | Memory networks.CoRR, abs/1410.3916 -> 仅元数据
- `R001` | `skipped_limit` | CoRR, abs/1607.06450 -> 仅元数据
- `R002` | `skipped_limit` | Semi-Supervised Learning. 2006 -> 仅元数据
- `R003` | `skipped_limit` | Induct ive representation learning on large graphs -> 仅元数据
- `R004` | `skipped_limit` | Deep R esidual Learning for Image Recognition -> 仅元数据
- `R005` | `skipped_limit` | Combining neural networks with personalized pagerank for classification on graphs -> 仅元数据
- `R006` | `skipped_limit` | Can GCNs go as deep as CNNs? CoRR, abs/1904.03751 -> 仅元数据
- `R007` | `skipped_limit` | Deeper Insights int o Graph Convolutional Networks for Semi-Supervised Learning -> 仅元数据
- `R008` | `skipped_limit` | Gmnn: Graph markov neu ral networks -> 仅元数据
- `R009` | `skipped_limit` | Weight normalization: A simple reparameterization to accelerate training of deep neural networks -> 仅元数据
- `R010` | `skipped_limit` | Collective classification in network data. AI magazine, 29(3):93–93 -> 仅元数据
- `R011` | `skipped_limit` | Pitfalls of graph neural network evaluation -> 仅元数据
- `R012` | `skipped_limit` | Graph attention networks -> 仅元数据
- `R013` | `skipped_limit` | Simplifying graph convolutional networks -> 仅元数据
- `R014` | `skipped_limit` | Representation Learning on Graphs with Jumping Kn owledge Networks -> 仅元数据
- `R001` | `skipped_limit` | Graph convolutional encoders for syntax-aware neural machine translation -> 仅元数据
- `R001` | `skipped_limit` | Mixhop: Higher-order graph convolutional architectures via sparsified neighborhood mixing -> 仅元数据
- `R002` | `skipped_limit` | Fastgcn: Fast learning with graph convolutional networks via importance sampling -> 仅元数据
- `R003` | `skipped_limit` | Stochastic training of graph convolutional networks with variance reduction -> 仅元数据
- `R004` | `skipped_limit` | Cluster-gcn: An efficient algorithm for training deep and large graph convolutional networks -> 仅元数据
- `R005` | `skipped_limit` | Four proofs for the cheeger inequality and graph partition algorithms -> 仅元数据
- `R006` | `skipped_limit` | Neuralbrane: Neural bayesian personalized ranking for attributed network embedding -> 仅元数据
- `R007` | `skipped_limit` | Convolutional neural networks on graphs with fast localized spectral filtering -> 仅元数据
- `R008` | `skipped_limit` | Fast graph representation learning with PyTorch Geometric -> 仅元数据
- `R009` | `skipped_limit` | Protein interface prediction using graph convolutional networks -> 仅元数据
- `R010` | `skipped_limit` | Graph u-nets -> 仅元数据
- `R011` | `skipped_limit` | Attention based spatial-temporal graph convolutional networks for traffic flow forecasting -> 仅元数据
- `R012` | `skipped_limit` | Inductive representation learning on large graphs -> 仅元数据
- `R013` | `skipped_limit` | Identity matters in deep learning -> 仅元数据
- `R014` | `skipped_limit` | Deep residual learning for image recognition -> 仅元数据
- `R015` | `skipped_limit` | Adaptive sampling towards fast graph representation learning -> 仅元数据
- `R016` | `skipped_limit` | Adam: A method for stochastic optimization -> 仅元数据
- `R017` | `skipped_limit` | Semi-supervised classification with graph convolutional networks -> 仅元数据
- `R018` | `skipped_limit` | Predict then propagate: Graph neural networks meet personalized pagerank -> 仅元数据
- `R019` | `skipped_limit` | Diffusion improves graph learning -> 仅元数据
- `R020` | `skipped_limit` | Convolutional networks for images, speech, and time series -> 仅元数据
- `R021` | `skipped_limit` | Self-attention graph pooling -> 仅元数据
- `R022` | `skipped_limit` | Encoding social information with graph convolutional networks forpolitical perspective detection in news media -> 仅元数据
- `R023` | `skipped_limit` | Optimization algorithm inspired deep neural network structure design -> 仅元数据
- `R024` | `skipped_limit` | Predicting path failure in time-evolving graphs -> 仅元数据
- `R025` | `skipped_limit` | Deeper insights into graph convolutional networks for semi-supervised learning -> 仅元数据
- `R026` | `skipped_limit` | Adaptive graph convolutional neural networks -> 仅元数据
- `R027` | `skipped_limit` | Geniepath: Graph neural networks with adaptive receptive paths -> 仅元数据
- `R028` | `skipped_limit` | MMM: multi-source multi-net micro-video recommendation with clustered hidden item representation learning -> 仅元数据
- `R029` | `skipped_limit` | Graph neural networks exponentially lose expressive power for node classification -> 仅元数据
- `R030` | `skipped_limit` | The pagerank citation ranking: Bringing order to the web -> 仅元数据

## Evidence Limitations

- 只使用以上论文页面中已记录的 Evidence ID。
- `unavailable`、`unresolved` 和 `skipped_limit` 参考文献只有引用元数据，不属于已阅读证据。
- 模型推断不能替代论文作者明确陈述。
