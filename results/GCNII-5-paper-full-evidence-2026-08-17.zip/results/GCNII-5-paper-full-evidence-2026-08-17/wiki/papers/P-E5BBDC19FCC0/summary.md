# 03-PairNorm

## 基本信息
- Paper ID: `P-E5BBDC19FCC0`
- 原始文件: `paper/uploads/03-PairNorm.pdf`
- Wiki PDF: `wiki/papers/P-E5BBDC19FCC0/source.pdf`

## 研究问题

- 待根据论文证据补充。

## 核心方法

- 待根据论文证据补充。

## 数据集与实验设置

- 待根据论文证据补充。

## 主要结果

- 待根据论文证据补充。

## 作者讨论与局限

- 未确认。

## 作者提出的未来工作

- 未确认。

## 作者明确指出的 Gap

- 未确认。

## 基于证据推断的 Gap

- 未确认。

## 可复用证据

- `PE-4D863AEFC9` | 第 7 页 | Published as a conference paper at ICLR 2020 ual connected” SGC), as we surprisingly ﬁnd it can slow down o versmoothing and beneﬁt SSNC- MV problem. Similar to us, residual connection is a general t echnique that can be applied to any model without changing its architecture. We focus on the com parison between the base models and PAIR NORM -enhanced models, rather than achieving the state of the art performance for SSNC and SSNC-MV. There exist a few other work addressing oversmooth ing (Klicpe
- `PE-D8465AA5C9` | 第 1 页 | arXiv:1909.12223v2  [cs.LG]  13 Feb 2020 Published as a conference paper at ICLR 2020 PAIR NORM : T ACKLING OVERSMOOTHING IN GNN S Lingxiao Zhao Carnegie Mellon University Pittsburgh, P A 15213, USA {lingxia1}@andrew.cmu.edu Leman Akoglu Carnegie Mellon University Pittsburgh, P A 15213, USA {lakoglu}@andrew.cmu.edu ABSTRACT The performance of graph neural nets (GNNs) is known to gradu ally decrease with increasing number of layers. This decay is partly attri buted to oversmooth- ing, where repea
- `PE-1DC202CA43` | 第 8 页 | Published as a conference paper at ICLR 2020 GA T-PN achieve performance that is comparable or better tha n just using skips; (4) performance can be further improved (albeit slightly) by using skips alo ng with PAIR NORM -SI.4 Table 2: Comparison of ‘vanilla’ and (P AIR NORM -SI/ residual)-enhanced GCN performance on Cora, Citeseer, Pubmed, and CoauthorCS for SSNC-MV problem, with 0% and 100% feature missing rate. t represents the skip-step of residual connection. (See A.5 F ig. 8 for more setti
- `PE-9A7D4298E4` | 第 6 页 | Published as a conference paper at ICLR 2020 of SGC on Cora with increasing number of layers, where we employ P AIR NORM after each graph convolution layer, as compared to ‘vanilla’ versions. Simi larly, Figure 3 is for GCN and GA T (PAIR NORM is applied after the activation of each graph convolution). Note that the performance decay with P AIR NORM -at-work is much slower. (See Fig.s 5–6 in Appx. A.3 for other datasets.) While PAIR NORM enables deeper models that are more robust to oversmoothin

## 与其他论文的关系

- 暂无已验证关系。

## 对 Idea 生成的提示

- 仅使用上方可定位证据，证据不足处保持不确定。

## 证据边界与未确认内容

- 未确认。
