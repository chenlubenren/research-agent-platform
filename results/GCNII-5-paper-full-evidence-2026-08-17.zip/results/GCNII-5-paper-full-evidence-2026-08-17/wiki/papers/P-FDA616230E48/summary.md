# 01-GCNII

## 基本信息
- Paper ID: `P-FDA616230E48`
- 原始文件: `paper/uploads/01-GCNII.pdf`
- Wiki PDF: `wiki/papers/P-FDA616230E48/source.pdf`

## 研究问题

- 待根据论文证据补充。

## 核心方法

- 待根据论文证据补充。

## 数据集与实验设置

- 待根据论文证据补充。

## 主要结果

- 待根据论文证据补充。

## 作者讨论与局限

- 未确认。

## 作者提出的未来工作

- 未确认。

## 作者明确指出的 Gap

- 未确认。

## 基于证据推断的 Gap

- 未确认。

## 可复用证据

- `PE-A392E3B074` | 第 2 页 | Simple and Deep Graph Convolutional Networks powerful expression ability of deep nonlinear architectures, which means they are still shallow models. In conclusion, it remains an open problem to design a GCN model that effectively prevents over-smoothing and achieves state-of-the-art results with truly deep network structures. Due to this challenge, it is even unclear whether the network depth is a resource or a burden in designing new graph neu- ral networks. In this paper, we give a positive an
- `PE-7ECA9C7314` | 第 8 页 | Simple and Deep Graph Convolutional Networks Table 5. Mean classiﬁcation accuracy of full-supervised node classiﬁcation. Method Cora Cite. Pumb. Cham. Corn. Texa. Wisc. GCN 85.77 73.68 88.13 28.18 52.70 52.16 45.88 GAT 86.37 74.32 87.62 42.93 54.32 58.38 49.41 Geom-GCN-I 85.19 77.99 90.05 60.31 56.76 57.58 58.24 Geom-GCN-P 84.93 75.14 88.09 60.90 60.81 67.57 64.12 Geom-GCN-S 85.27 74.71 84.75 59.96 55.68 59.73 56.67 APPNP 87.87 76.53 89.40 54.3 73.51 65.41 69.02 JKNet 85.25 (16) 75.85 (8) 88.94 
- `PE-72611C7183` | 第 4 页 | Simple and Deep Graph Convolutional Networks Wℓ to avoid over-ﬁtting, while the later is desirable in semi-supervised tasks where training data is limited. • (Oono & Suzuki, 2020) theoretically proves that the node features of a K-layer GCNs will converge to a subspace and incur information loss. In particular, the rate of convergence depends on sK, where s is the maximum singular value of the weight matrices W(ℓ),ℓ = 0,...,K −1. By replacing W(ℓ) with (1− βℓ)In +βℓW(ℓ) and imposing regularizati

## 与其他论文的关系

- 暂无已验证关系。

## 对 Idea 生成的提示

- 仅使用上方可定位证据，证据不足处保持不确定。

## 证据边界与未确认内容

- 未确认。
