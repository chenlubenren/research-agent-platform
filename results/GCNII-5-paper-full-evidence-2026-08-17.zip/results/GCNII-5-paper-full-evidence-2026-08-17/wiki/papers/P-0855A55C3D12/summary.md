# 05-DropEdge

## 基本信息
- Paper ID: `P-0855A55C3D12`
- 原始文件: `paper/uploads/05-DropEdge.pdf`
- Wiki PDF: `wiki/papers/P-0855A55C3D12/source.pdf`

## 研究问题

- 待根据论文证据补充。

## 核心方法

- 待根据论文证据补充。

## 数据集与实验设置

- 待根据论文证据补充。

## 主要结果

- 待根据论文证据补充。

## 作者讨论与局限

- 未确认。

## 作者提出的未来工作

- 未确认。

## 作者明确指出的 Gap

- 未确认。

## 基于证据推断的 Gap

- 未确认。

## 可复用证据

- `PE-D2390D1E22` | 第 5 页 | Published as a conference paper at ICLR 2020 Deﬁnition 1 (subspace). LetM :={EC|C∈ RM×C} be anM-dimensional subspace in RN×C, where E∈ RN×M is orthogonal, i.e. ETE = IM , andM≤N. Deﬁnition 2 (ϵ-smoothing). We call theϵ-smoothing of node features happens for a GCN, if all its hidden vectors H (l) beyond a certain layerL have a distance no larger thanϵ (ϵ> 0) with respect to a subspaceM that is independent to the input features, namely, dM(H (l))<ϵ,∀l≥L, (3) wheredM(·) computes the distance betwee
- `PE-1D5C687408` | 第 4 页 | Published as a conference paper at ICLR 2020 4 O UR METHOD : D ROPEDGE This section ﬁrst introduces the methodology of the DropEdge technique as well as its layer-wise variant where the adjacency matrix for each GCN layer is perturbed individually. We also explain how the proposed DropEdge can prevent over-ﬁtting and over-smoothing in generic GCNs. Particularly for over-smoothing, we provide its mathematical deﬁnition and theoretical derivations on showing the beneﬁts of DropEdge. 4.1 M ETHODOLO
- `PE-9405D2A162` | 第 3 页 | Published as a conference paper at ICLR 2020 Gao et al., 2018). These methods directly perform convolution in the graph domain by aggregating the information from neighbor nodes. Recently, several sampling-based methods have been proposed for fast graph representation learning, including the node-wise sampling methods (Hamilton et al., 2017), the layer-wise approach (Chen et al., 2018) and its layer-dependent variant (Huang et al., 2018). Speciﬁcally, GAT (Velickovic et al., 2018) has discussed 
- `PE-881757B87C` | 第 15 页 | Published as a conference paper at ICLR 2020 B.3 T HE VALIDATION LOSS ON DIFFERENT BACKBONES W AND W /O DROPEDGE . Figure 6 depicts the additional results of validation loss on different backbones w and w/o DropEdge. 0 25 50 75 100 125 150 175 200 Epoch 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2Validation Loss Cora ResGCN-6 GCN-6 InceptGCN-6 JKNet-6 ResGCN-6+DropEdge GCN-6+DropEdge InceptGCN-6+DropEdge JKNet-6+DropEdge 0 25 50 75 100 125 150 175 200 Epoch 0.8 1.0 1.2 1.4 1.6 1.8 2.0Validation Loss Cite
- `PE-E97CAD797D` | 第 2 页 | Published as a conference paper at ICLR 2020 0 50 100 150 200 250 300 350 400 Epochs 0.25 0.75 1.25 1.75 Training Loss GCN-8 GCN-8+DropEdge GCN-4 GCN-4+DropEdge 0 50 100 150 200 250 300 350 400 Epochs 0.25 0.75 1.25 1.75 Validation Loss GCN-8 GCN-8+DropEdge GCN-4 GCN-4+DropEdge Figure 1: Performance of Multi-layer GCNs on Cora. We implement 4-layer GCN w and w/o DropEdge (in orange), 8-layer GCN w and w/o DropEdge (in blue) 2. GCN-4 gets stuck in the over-ﬁtting issue attaining low training erro

## 与其他论文的关系

- 暂无已验证关系。

## 对 Idea 生成的提示

- 仅使用上方可定位证据，证据不足处保持不确定。

## 证据边界与未确认内容

- 未确认。
