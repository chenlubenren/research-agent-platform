# 04-GAT

## 基本信息
- Paper ID: `P-A7D811A44E1C`
- 原始文件: `paper/uploads/04-GAT.pdf`
- Wiki PDF: `wiki/papers/P-A7D811A44E1C/source.pdf`

## 研究问题

- 待根据论文证据补充。

## 核心方法

- 待根据论文证据补充。

## 数据集与实验设置

- 待根据论文证据补充。

## 主要结果

- 待根据论文证据补充。

## 作者讨论与局限

- 未确认。

## 作者提出的未来工作

- 未确认。

## 作者明确指出的 Gap

- 未确认。

## 基于证据推断的 Gap

- 未确认。

## 可复用证据

- `PE-491F3AB11C` | 第 3 页 | Published as a conference paper at ICLR 2018 sharing a neural network computation across edges is reminiscent of the formulation of relational networks (Santoro et al., 2017) and V AIN (Hoshen, 2017), wherein relations between objects or agents are aggregated pair-wise, by employing a shared mechanism. Similarly, our proposed at- tention model can be connected to the works by Duan et al. (2017) and Denil et al. (2017), which use a neighborhood attention operation to compute attention coefﬁcients
- `PE-976F54AC25` | 第 9 页 | Published as a conference paper at ICLR 2018 The effectiveness of the learned feature representations may also be investigated qualitatively—and for this purpose we provide a visualization of the t-SNE (Maaten & Hinton, 2008)-transformed feature representations extracted by the ﬁrst layer of a GAT model pre-trained on the Cora dataset (Figure 2). The representation exhibits discernible clustering in the projected 2D space. Note that these clusters correspond to the seven labels of the dataset, v
- `PE-F9BB16CB19` | 第 5 页 | Published as a conference paper at ICLR 2018 all nodes. No eigendecompositions or similar costly matrix operations are required. The time complexity of a single GAT attention head computing F′ features may be expressed asO(|V|FF′ +|E|F′), whereF is the number of input features, and|V| and|E| are the numbers of nodes and edges in the graph, respectively. This complexity is on par with the baseline methods such as Graph Convolutional Networks (GCNs) (Kipf & Welling, 2017). Applying multi-head atte
- `PE-DE2ABEF1EE` | 第 8 页 | Published as a conference paper at ICLR 2018 Table 2: Summary of results in terms of classiﬁcation accuracies, for Cora, Citeseer and Pubmed. GCN-64∗ corresponds to the best GCN result computing 64 hidden features (using ReLU or ELU). Transductive Method Cora Citeseer Pubmed MLP 55.1% 46.5% 71.4% ManiReg (Belkin et al., 2006) 59.5% 60.1% 70.7% SemiEmb (Weston et al., 2012) 59.0% 59.6% 71.7% LP (Zhu et al., 2003) 68.0% 45.3% 63.0% DeepWalk (Perozzi et al., 2014) 67.2% 43.2% 65.3% ICA (Lu & Getoor

## 与其他论文的关系

- 暂无已验证关系。

## 对 Idea 生成的提示

- 仅使用上方可定位证据，证据不足处保持不确定。

## 证据边界与未确认内容

- 未确认。
