# 02-DeepGCNs

## 基本信息
- Paper ID: `P-C82A044DF1BD`
- 原始文件: `paper/uploads/02-DeepGCNs.pdf`
- Wiki PDF: `wiki/papers/P-C82A044DF1BD/source.pdf`

## 研究问题

- 待根据论文证据补充。

## 核心方法

- 待根据论文证据补充。

## 数据集与实验设置

- 待根据论文证据补充。

## 主要结果

- 待根据论文证据补充。

## 作者讨论与局限

- 未确认。

## 作者提出的未来工作

- 未确认。

## 作者明确指出的 Gap

- 未确认。

## 基于证据推断的 Gap

- 未确认。

## 可复用证据

- `PE-53D0389F49` | 第 1 页 | DeepGCNs: Can GCNs Go as Deep as CNNs? https://sites.google.com/view/deep-gcns Guohao Li∗ Matthias M¨uller∗ Ali Thabet Bernard Ghanem Visual Computing Center, KAUST, Thuwal, Saudi Arabia {guohao.li, matthias.mueller.2, ali.thabet, bernard.ghanem }@kaust.edu.sa Abstract Convolutional Neural Networks (CNNs) achieve impres- sive performance in a wide variety of ﬁelds. Their success beneﬁted from a massive boost when very deep CNN models were able to be reliably trained. Despite their merits, CNNs f
- `PE-7ABF7565E8` | 第 2 页 | In this work, we present an extensive study of method- ologies that allow for training very deep GCNs. We adapt concepts that were successful in training deep CNNs, mainly residual connections, dense connections, and dilated convolutions. We show how we can incorporate these layers into a graph framework, and present an extensive analysis of the effect of these additions to the accuracy and stabil- ity of deep GCNs. To showcase these layer adaptations, we apply them to the popular task of point 
- `PE-DF3F83AD8D` | 第 7 页 | Ablation Model mIoU ∆mIoU dynamic connection dilation stochastic # NNs # ﬁlters # layers Reference ResGCN-28 52.49 0.00 ✓ ⊕ ✓ ✓ 16 64 28 Dilation 51.98 -0.51 ✓ ⊕ ✓ 16 64 28 49.64 -2.85 ✓ ⊕ 16 64 28 PlainGCN-28 40.31 -12.18 ✓ 16 64 28 Fixed k-NN 48.38 -4.11 ⊕ 16 64 28 43.43 -9.06 16 64 28 Connections DenseGCN-28 51.27 -1.22 ✓ ⊿ ◁ ✓ ✓ 8 32 28 40.47 -12.02 ✓ ✓ ✓ 16 64 28 38.79 -13.70 ✓ ✓ ✓ 8 64 56 49.23 -3.26 ✓ ✓ ✓ 16 64 14 47.92 -4.57 ✓ ✓ ✓ 16 64 7 Neighbors 49.98 -2.51 ✓ ⊕ ✓ ✓ 8 64 28 49.22 -3.27
- `PE-E6DA272E52` | 第 12 页 | Model mIoU ∆mIoU dynamic connection dilation stochastic # NNs # ﬁlters # layers ResEdgeConv-28 52.49 0.00 ✓ ⊕ ✓ ✓ 16 64 28 PlainGCN-28 40.31 -12.18 ✓ 16 64 28 ResGraphSAGE-28 49.20 -3.29 ✓ ⊕ ✓ ✓ 16 64 28 ResGraphSAGE-N-28 49.02 -3.47 ✓ ⊕ ✓ ✓ 16 64 28 ResGIN-ϵ-28 42.81 -9.68 ✓ ⊕ ✓ ✓ 16 64 28 ResMRGCN-28 51.17 -1.32 ✓ ⊕ ✓ ✓ 16 64 28 Table 3. Comparisons of Deep GCNs variants on area 5 of S3DIS . We compare our different types of ResGCN ( ResEdgeConv, Res- GraphSAGE, ResGIN and ResMRGCN) with 28 la

## 与其他论文的关系

- 暂无已验证关系。

## 对 Idea 生成的提示

- 仅使用上方可定位证据，证据不足处保持不确定。

## 证据边界与未确认内容

- 未确认。
