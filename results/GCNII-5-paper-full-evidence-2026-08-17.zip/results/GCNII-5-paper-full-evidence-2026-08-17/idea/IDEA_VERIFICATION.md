# Candidate Under Review

收窄后的候选研究问题为：在何种深度区间和图结构条件下，结构层面（DropEdge 的边丢弃）与权重层面（GCNII 的恒等映射 $(1-\beta_\ell)I_n + \beta_\ell W^{(\ell)}$）的过平滑控制产生互补或冗余。该候选源自 GCNII 指出的开放问题——"设计有效防止过平滑且在真正深层结构上达到先进性能的 GCN 模型仍是一个开放问题"（PE-A392E3B074, p2），但收窄后不再以"正交性"为前提，而是要求实验区分互补区间与冗余区间。

# Closest Prior Work

1. **PairNorm + 残差连接组合实验**（PE-1DC202CA43, p8）：PairNorm 已与残差连接组合使用，实验显示"GAT-PN achieve performance that is comparable or better than just using skips; performance can be further improved (albeit slightly) by using skips along with PAIRNORM-SI"。这直接证明特征层面与残差层面的过平滑控制组合已有先例，且边际增益被描述为"albeit slightly"。

2. **GCNII 自身的双机制组合**（PE-72611C7314, p4）：GCNII 通过将 $W^{(\ell)}$ 替换为 $(1-\beta_\ell)I_n + \beta_\ell W^{(\ell)}$ 同时引入初始残差连接和恒等映射，本身已是权重层面与残差层面的组合。其理论依据为 Oono & Suzuki 证明的收敛速率依赖 $s^K$（PE-72611C7183, p4）。

3. **DropEdge 作为通用插件的多骨干验证**（PE-881757B87C, p15）：DropEdge 已在 ResGCN、InceptGCN、JKNet 等骨干上测试，说明结构层面干预与其他架构组件的组合已被系统探索。

# Novelty Stress Test

| 检查项 | 评估 |
|---|---|
| 作者明确指出的 Gap | 部分支持。GCNII 指出深层 GCN 防过平滑是开放问题（PE-A392E3B074, p2），但未明确提出"刻画不同层面控制的交互边界"这一具体问题。 |
| 是否只是作者 Future Work | 无法排除。五篇论文的 Future Work 均标注"未确认"（wiki query pack），不能断言该方向不在作者建议范围内。 |
| 是否已有论文完成 | 五篇论文证据中未发现"结构层面 vs 权重层面交互边界"的直接实验，但 PairNorm + 残差的组合实验（PE-1DC202CA43, p8）已展示了类似的组合范式。 |
| 是否至少由两篇论文支持 | 是。DropEdge 的结构层面操作由 PE-1D5C687408 (p4) 支持；GCNII 的权重层面操作由 PE-72611C7314 (p4) 支持；ε-smoothing 定义由 PE-D2390D1E22 (p5) 提供。 |
| 方法差异是否具体 | 收窄后差异较明确：不是简单组合，而是要求刻画互补/冗余的深度区间与图结构条件边界。但"交互边界"的操作化定义仍不够具体。 |
| 是否能设计对照实验 | 是。可设计不同深度 × 不同图结构条件下的消融实验，比较单独使用、组合使用时的性能差异与过平滑指标变化。 |
| 是否有可证伪失败标准 | 是。若在所有测试条件下组合均不优于单独使用的最佳者，则"互补区间存在"假设被证伪。 |
| 最大重复风险 | PairNorm + 残差组合已展示"albeit slightly"的边际增益（PE-1DC202CA43, p8），若收窄后的研究仅得出类似结论，则贡献不足。 |
| 最大证据风险 | 证据覆盖仅限五篇论文，103 条参考文献均为仅元数据（wiki query pack），无法确认外部是否已有更直接的交互边界研究。 |

# Feasibility Stress Test

实验成本较低：仅需在 Cora、Citeseer 等小数据集上训练多层 GCN 并记录性能与过平滑指标。DropEdge 已在 GCN-4/8 上验证（PE-E97CAD797D, p2），GCNII 已在 Cora/Citeseer/Pubmed 上报告分类精度（PE-7ECA9C7314, p8），DeepGCNs 在 S3DIS 上提供了 28 层模型的消融框架（PE-DF3F83AD8D, p7）。主要可行性风险在于：收窄后的研究问题要求系统扫描深度区间与图结构条件，实验组合空间可能较大，但可通过合理缩减条件数控制。

# Disconfirming Evidence

1. PairNorm + 残差连接的组合实验显示边际增益"albeit slightly"（PE-1DC202CA43, p8），暗示不同层面过平滑控制的组合收益可能递减，收窄后的候选若仅得出类似结论则学术价值有限。

2. GCNII 已在权重层面同时实现恒等映射与初始残差连接（PE-72611C7314, p4），其本身已是一种"组合"，再叠加 DropEdge 属于三机制叠加，现有证据未证明第三层叠加的边际收益。

3. DropEdge 的 ε-smoothing 理论分析（PE-D2390D1E22, p5）与 GCNII 依据的 Oono & Suzuki 收敛速率理论（PE-72611C7314, p4）基于不同的数学框架，两者是否可统一度量尚未被证据支持。

# Unresolved Questions

1. 五篇论文的作者 Future Work 均未确认，无法排除该方向与作者建议重叠的风险。
2. 证据覆盖仅限五篇论文，103 条参考文献均为仅元数据，外部文献中是否已有"过平滑控制机制交互边界"的直接研究无法确认。
3. "互补区间"与"冗余区间"的操作化判定标准——以性能差异为唯一判据，还是需结合过平滑指标（如 ε-smoothing 距离、Dirichlet energy）——在现有证据中未被定义。
4. DropEdge 的 ε-smoothing 定义（PE-D2390D1E22, p5）与 GCNII 的收敛速率框架（PE-72611C7314, p4）是否可在统一度量下比较，缺乏证据支持。

# Verification Verdict

**裁定：收窄后有条件保留（Narrow with conditions）**

收窄后的候选比原始"正交性验证"形式更具可证伪性和学术价值，但仍需满足以下条件方可进入 `/plan` 阶段：

1. 必须明确"互补"与"冗余"的操作化判据，不能仅以最终分类精度差异为唯一标准，应结合至少一种过平滑度量（如 ε-smoothing 距离 PE-D2390D1E22, p5 或特征方差比 PE-9A7D4298E4, p6）。
2. 必须在实验设计中包含"单独 DropEdge""单独 GCNII 恒等映射""两者组合"三组对照，且深度扫描范围应覆盖浅层（2-4 层）到深层（16-64 层）。
3. 禁止在当前阶段承诺具体数据集划分、超参数范围或层数配置。
4. 研究贡献的定位应从"发现正交性"调整为"刻画两种过平滑控制机制的交互边界及其条件依赖性"，避免与 PairNorm + 残差组合实验（PE-1DC202CA43, p8）的已有结论重复。
