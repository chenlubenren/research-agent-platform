# GCNII 五篇论文完整证据测试结果

本结果包对应 2026 年 8 月 17 日完成的一次真实 `/wiki` → `/idea` 全流程测试。

## 输入论文

- GCNII：深层图卷积网络的恒等映射与初始残差
- DeepGCNs：深层图卷积网络
- PairNorm：缓解图神经网络过平滑
- GAT：图注意力网络
- DropEdge：面向深层图卷积网络的随机边丢弃

## 包含内容

- `idea/FINAL_IDEA.md`：最终 Idea 输出
- `idea/IDEA_CANDIDATES.md`：候选 Idea
- `idea/IDEA_VERIFICATION.md`：批评与核验结果
- `Content/IDEA_TRACE.json`：阶段、耗时、证据和门槛追踪
- `wiki/query_pack.md`：五篇论文的证据包和跨论文证据矩阵
- `wiki/papers/`：每篇论文的 `source.pdf` 和 `summary.md`

## 结果说明

- 五篇论文均具备 PDF、Markdown 总结和 Evidence ID，达到数量门槛。
- 流程完整执行了 Wiki 整理、候选生成、批评核验和最终定稿。
- 最终结果仍可能是 `blocked_preliminary`，因为数量达标不等于创新性和证据风险已经解决。
- 该结果用于复核流程是否正确工作，不代表论文已经可以投稿或保证发表。
